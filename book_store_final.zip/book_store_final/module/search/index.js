"use client";

import Loading from "@/components/loading";
import ProductCard from "@/components/product-card";
import { getBooks } from "@/services/products";
import React, { useEffect, useState } from "react";

const Search = () => {
  const [books, setBooks] = useState(null);
  const [query, setQuery] = useState("");
  const [booksLoading, setBooksLoading] = useState(true);
  useEffect(() => {
    const fetchBookData = async () => {
      const data = await getBooks();
      setBooks(data);
      setBooksLoading(false);
    };
    fetchBookData();
  }, []);

  if (booksLoading) return <Loading />;

  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="border-2">
        <input
          placeholder="Search Book"
          onChange={(e) => setQuery(e.target.value)}
          className="p-4 w-full"
        />
      </div>
      <div className="grid lg:grid-cols-3 grid-cols-1 w-full">
        {books &&
          books
            .filter((book) =>
              book?.title.toLowerCase().includes(query.toLowerCase())
            )
            .map((book) => <ProductCard key={book.ISBN} book={book} />)}
      </div>
    </div>
  );
};

export default Search;
