"use server";

import axios from "axios";

export const registerUser = async (data) => {
  try {
    const response = await axios.post("https://api.escuelajs.co/api/v1/users", {
      email: data.email,
      name: data.name,
      password: data.password,
      role: "customer",
      avatar:
        "https://static.vecteezy.com/system/resources/thumbnails/005/129/844/small_2x/profile-user-icon-isolated-on-white-background-eps10-free-vector.jpg",
    });

    return response.data;
  } catch (error) {
    console.error("Error registering user:", error);
    throw error;
  }
};

export const loginUser = async ({ email, password }) => {
  try {
    const response = await axios.post(
      "https://api.escuelajs.co/api/v1/auth/login",
      {
        email: email,
        password: password,
      }
    );

    return response.data;
  } catch (error) {
    console.error("Error logging in:", error);
    throw error;
  }
};

export const getMe = async (token) => {
  try {
    const profile = await axios.get(
      `https://api.escuelajs.co/api/v1/auth/profile`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return profile.data;
  } catch (error) {
    console.log(error);
  }
};

export const updateProfile = async ({ id, name, email, password, avatar }) => {
  try {
    const profile = await axios.put(
      `https://api.escuelajs.co/api/v1/users/${id}`,
      {
        name,
        email,
        password,
        role: "customer",
        avatar: avatar,
      }
    );
    return profile.data;
  } catch (error) {
    console.log(error);
  }
};
