"use client";

import ProductCard from "@/components/product-card";
import SkeletonCard from "@/components/skeleton-card";
import { highlightedAuthors } from "@/services/products";
import React, { useEffect, useState } from "react";
import { SwiperSlide } from "swiper/react";

const Products = () => {
  const [fetchAuthorLoading, setFetchAuthorLoading] = useState(true);
  const [bestAuthor, setBestAuthor] = useState(null);

  useEffect(() => {
    const fetchAuthor = async () => {
      const recommendedaAuthors = await highlightedAuthors();
      setBestAuthor(recommendedaAuthors);
      setFetchAuthorLoading(false);
    };
    fetchAuthor();
  }, []);
  const authorData = bestAuthor?.highlightedBooks ?? [];

  return (
    <div className="mx-auto max-w-7xl">
      <h1 className="text-3xl font-semibold">Highlighted Authors</h1>

      <div className="w-full gap-6 grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1">
        {fetchAuthorLoading
          ? Array.from({ length: 3 }).map((_, index) => (
              <SwiperSlide key={_}>
                <SkeletonCard key={index} />
              </SwiperSlide>
            ))
          : authorData &&
            authorData.map((book) => (
              <SwiperSlide key={book.ISBN}>
                <ProductCard book={book} />
              </SwiperSlide>
            ))}
      </div>
    </div>
  );
};

export default Products;
