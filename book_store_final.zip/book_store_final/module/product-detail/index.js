"use client";

import Loading from "@/components/loading";
import { addToCart } from "@/redux/slice/cart";
import { getBooks } from "@/services/products";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { toast } from "react-toastify";

const ProductDetail = ({ isbn }) => {
  const [bookDetail, setBookDetail] = useState(null);
  const dispatch = useDispatch();

  useEffect(() => {
    const fetchDetail = async () => {
      const bookDetail = await getBooks();
      setBookDetail(bookDetail);
    };
    fetchDetail();
  }, []);
  const detail =
    bookDetail && bookDetail.filter((book) => book.ISBN == isbn)[0];
  console.log(detail);
  if (!detail) return <Loading />;

  return (
    <section className="relative">
      <div className="w-full mx-auto px-4 sm:px-6 lg:px-0">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mx-auto max-md:px-2">
          <div className="img">
            <div className="img-box h-full max-lg:mx-auto">
              <img
                src={detail?.image}
                alt={detail?.title}
                className="max-lg:mx-auto object-cover lg:ml-auto h-full"
              />
            </div>
          </div>
          <div className="data w-full lg:pr-8 pr-0 xl:justify-start justify-center flex items-center max-lg:pb-10 xl:my-2 lg:my-5 my-0">
            <div className="max-w-xl">
              <h2 className="font-manrope font-bold text-3xl leading-10 text-gray-900 mb-2 capitalize">
                {detail?.title}
              </h2>
              <div className="flex flex-col sm:flex-row sm:items-center mb-6">
                <h6 className="font-manrope font-semibold text-2xl leading-9 text-gray-900 pr- mr-5">
                  {detail?.price?.value} {detail?.price?.currency}
                </h6>
              </div>
              <span className="text-gray-500 text-base font-normal mb-5">
                {detail?.summary}
              </span>
              <button
                className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md"
                onClick={() => {
                  dispatch(addToCart(detail));
                  toast.success("Product Added to Cart");
                }}
              >
                Add to Cart
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductDetail;
