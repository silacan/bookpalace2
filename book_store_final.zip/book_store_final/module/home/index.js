"use client";

import ProductCard from "@/components/product-card";
import SkeletonCard from "@/components/skeleton-card";
import { getBooks, highlightedAuthors } from "@/services/products";
import React, { useEffect, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper/modules";

const Home = () => {
  const [books, setBooks] = useState(null);
  const [booksLoading, setBooksLoading] = useState(true);
  const [bestAuthor, setBestAuthor] = useState(null);

  useEffect(() => {
    const fetchBookData = async () => {
      const data = await getBooks();
      setBooks(data);
      setBooksLoading(false);
    };
    fetchBookData();
  }, []);
  const authorData = bestAuthor?.highlightedBooks ?? [];

  return (
    <div className="mx-auto max-w-7xl">
      <h1 className="text-3xl font-semibold">Best Sellers</h1>
      <Swiper
        slidesPerView={1}
        navigation={true}
        modules={[Navigation]}
        breakpoints={{
          400: {
            slidesPerView: 1,
            spaceBetween: 20,
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 40,
          },
          1024: {
            slidesPerView: 4,
            spaceBetween: 50,
          },
        }}
      >
        {booksLoading
          ? Array.from({ length: 3 }).map((_, index) => (
              <SwiperSlide key={index}>
                <SkeletonCard key={index} />
              </SwiperSlide>
            ))
          : books &&
            books.map((book) => (
              <SwiperSlide key={book.ISBN}>
                <ProductCard book={book} />
              </SwiperSlide>
            ))}
      </Swiper>
    </div>
  );
};

export default Home;
