"use client";

import { getMe } from "@/services/products";
import Cookies from "js-cookie";
import moment from "moment";
import React, { useEffect, useState } from "react";
import { CiSettings } from "react-icons/ci";
import { updateProfile } from "../auth/services/auth";
import { toast } from "react-toastify";

const Profile = () => {
  const [user, setUser] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [info, setInfo] = useState(null);

  const fetchMe = async () => {
    const token = Cookies.get("auth_token");
    const me = await getMe(token);
    setUser(me);
  };

  useEffect(() => {
    fetchMe();
  }, []);

  const handleUpdate = async () => {
    await updateProfile({
      id: user.id,
      ...info,
      avatar: user.avatar,
    });
    toast.success("Profile Updated");
    fetchMe();
    setIsModalOpen(false);
  };

  return (
    <>
      <section className="pt-16 bg-blueGray-50 relative">
        <div className="w-full lg:w-4/12 px-4 mx-auto">
          {!user ? (
            <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-xl rounded-lg mt-16 animate-pulse p-5">
              <div className="flex items-center justify-center h-48 mb-4 bg-gray-300 rounded ">
                <svg
                  className="w-10 h-10 text-gray-200"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="currentColor"
                  viewBox="0 0 16 20"
                >
                  <path d="M14.066 0H7v5a2 2 0 0 1-2 2H0v11a1.97 1.97 0 0 0 1.934 2h12.132A1.97 1.97 0 0 0 16 18V2a1.97 1.97 0 0 0-1.934-2ZM10.5 6a1.5 1.5 0 1 1 0 2.999A1.5 1.5 0 0 1 10.5 6Zm2.221 10.515a1 1 0 0 1-.858.485h-8a1 1 0 0 1-.9-1.43L5.6 10.039a.978.978 0 0 1 .936-.57 1 1 0 0 1 .9.632l1.181 2.981.541-1a.945.945 0 0 1 .883-.522 1 1 0 0 1 .879.529l1.832 3.438a1 1 0 0 1-.031.988Z" />
                  <path d="M5 5V.13a2.96 2.96 0 0 0-1.293.749L.879 3.707A2.98 2.98 0 0 0 .13 5H5Z" />
                </svg>
              </div>
              <div className="h-2.5 bg-gray-200 rounded-full  w-full mb-2"></div>
              <div className="h-2.5 bg-gray-200 rounded-full  w-full mb-2"></div>
              <div className="h-2.5 bg-gray-200 rounded-full  w-full mb-2"></div>
            </div>
          ) : (
            <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-xl rounded-lg mt-16">
              <div className="px-6">
                <div className="flex flex-wrap justify-center">
                  <div className="w-full px-4 flex justify-center relative">
                    <button
                      className="absolute right-3 top-3 bg-gray-100 rounded-lg"
                      onClick={() => setIsModalOpen(!isModalOpen)}
                    >
                      <CiSettings className="text-3xl" />{" "}
                    </button>
                    <div className="relative">
                      <img
                        alt={user?.name}
                        src={user?.avatar}
                        className="max-h-40"
                      />
                    </div>
                  </div>
                </div>
                <div className="text-center mt-12 flex justify-center flex-col items-center">
                  {isModalOpen ? (
                    <>
                      <div className="flex gap items-center gap-4">
                        <label>Name</label>
                        <input
                          type="text"
                          name="name"
                          defaultValue={user?.name}
                          onChange={(e) =>
                            setInfo({ ...info, name: e.target.value })
                          }
                          className="mb-2 px-3 py-2 border rounded"
                        />
                      </div>
                      <div className="flex gap items-center gap-4">
                        <label>Email</label>
                        <input
                          type="email"
                          name="email"
                          defaultValue={user?.email}
                          onChange={(e) =>
                            setInfo({ ...info, email: e.target.value })
                          }
                          className="mb-2 px-3 py-2 border rounded"
                        />
                      </div>
                      <div className="flex gap items-center gap-4">
                        <label>Password</label>
                        <input
                          type="password"
                          name="password"
                          defaultValue={user?.password}
                          onChange={(e) =>
                            setInfo({ ...info, password: e.target.value })
                          }
                          className="mb-2 px-3 py-2 border rounded"
                        />
                      </div>

                      <div className="mb-2 text-blueGray-600">
                        <i className="fas fa-briefcase mr-2 text-lg text-blueGray-400"></i>
                        <b>Role: </b>
                        {user?.role}
                      </div>
                      <div className="mb-2 text-blueGray-600">
                        <b>Date of registration: </b>
                        {moment(user?.creationAt).format("DD-MM-yyyy")}
                      </div>

                      <button
                        onClick={handleUpdate}
                        className="mt-2 px-4 py-2 bg-blue-500 text-white rounded mb-5"
                      >
                        Update
                      </button>
                    </>
                  ) : (
                    <>
                      <h3 className="text-xl font-semibold leading-normal text-blueGray-700 mb-2">
                        {user?.name}
                      </h3>
                      <div className="text-sm leading-normal mt-0 mb-2 text-blueGray-400 font-bold uppercase">
                        <i className="fas fa-map-marker-alt mr-2 text-lg text-blueGray-400"></i>
                        {user?.email}
                      </div>
                      <div className="mb-2 text-blueGray-600">
                        <i className="fas fa-briefcase mr-2 text-lg text-blueGray-400"></i>
                        <b>Role: </b>
                        {user?.role}
                      </div>
                      <div className="mb-2 text-blueGray-600">
                        <b>Date of registration: </b>
                        {moment(user?.creationAt).format("DD-MM-yyyy")}
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </>
  );
};

export default Profile;
