import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  cart: [],
  selectedCategoryId: 0,
};

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addToCart: (state, action) => {
      const product = action.payload;
      const existingItemIndex = state.cart.findIndex(
        (item) => item.product.ISBN === product.ISBN
      );

      if (existingItemIndex !== -1) {
        state.cart[existingItemIndex].quantity += 1;
      } else {
        state.cart.push({ product, quantity: 1 });
      }
    },
    removeFromCart: (state, action) => {
      const productId = action.payload;
      state.cart = state.cart.filter((item) => item.product.ISBN !== productId);
    },
    updateCartItemQuantity: (state, action) => {
      const { productId, quantity } = action.payload;
      const item = state.cart.find((item) => item.product.ISBN === productId);
      if (item) {
        item.quantity = quantity;
      }
    },
    setSelectedCategoryId: (state, action) => {
      state.selectedCategoryId = action.payload;
    },
  },
});

export const {
  addToCart,
  removeFromCart,
  updateCartItemQuantity,
  setSelectedCategoryId,
} = cartSlice.actions;
export default cartSlice.reducer;
