import axios from "axios";

export const getBooks = async () => {
  try {
    const books = await axios.get(
      "https://private-anon-8f02fa1111-bookstore.apiary-mock.com/data/books"
    );
    return books.data;
  } catch (error) {
    console.log(error);
  }
};

export const highlightedAuthors = async () => {
  try {
    const books = await axios.get(
      "https://private-anon-8f02fa1111-bookstore.apiary-mock.com/"
    );
    return books.data;
  } catch (error) {
    console.log(error);
  }
};

export const getBookDetail = async (isbn) => {
  try {
    const detail = await axios.get(
      `https://private-anon-8f02fa1111-bookstore.apiary-mock.com/books/${isbn}`
    );
    return detail.data;
  } catch (error) {
    console.log(error);
  }
};

export const getMe = async (token) => {
  try {
    const profile = await axios.get(
      `https://api.escuelajs.co/api/v1/auth/profile`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return profile.data;
  } catch (error) {
    console.log(error);
  }
};
