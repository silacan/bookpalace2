import dynamic from 'next/dynamic';

const Product = dynamic(() => import('@/module/products'), { ssr: false })

export default async function Page() {
  return <Product />;
}
