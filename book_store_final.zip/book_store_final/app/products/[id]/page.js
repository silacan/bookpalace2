import ProductDetail from "@/module/product-detail";

export default async function Page({ params }) {
  return <ProductDetail isbn={params.id} />;
}
