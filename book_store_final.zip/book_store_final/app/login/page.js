import dynamic from 'next/dynamic';

const Login = dynamic(() => import('@/module/auth/login'), { ssr: false })

export default async function Page() {
  return <Login />;
}
