import dynamic from 'next/dynamic';

const Basket = dynamic(() => import('@/module/basket'), { ssr: false })

export default async function Page() {
  return <Basket />;
}
