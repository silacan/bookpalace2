import dynamic from 'next/dynamic';

const Profile = dynamic(() => import('@/module/profile'), { ssr: false })

export default async function Page() {
  return <Profile />;
}
