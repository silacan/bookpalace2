import dynamic from 'next/dynamic';

const Search = dynamic(() => import('@/module/search'), { ssr: false })

export default async function Page() {
  return <Search />;
}
