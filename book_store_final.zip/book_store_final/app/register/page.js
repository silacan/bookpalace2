import dynamic from 'next/dynamic';

const Register = dynamic(() => import('@/module/auth/register'), { ssr: false })

export default async function Page() {
  return <Register />;
}
