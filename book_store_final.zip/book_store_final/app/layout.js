import { Inter } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import "react-toastify/dist/ReactToastify.css";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import { ToastContainer } from "react-toastify";
import StoreProvider from "@/provider/store-provider";
import { Suspense } from "react";
import Loading from "@/components/loading";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "BOOKPALACE",
  description: "for the CS391 course",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <StoreProvider>
        <body className={inter.className}>
          <Navbar />
          <Suspense>
            <div className="my-10 p-3">{children}</div>
          </Suspense>
          <Footer />
          <ToastContainer />
        </body>
      </StoreProvider>
    </html>
  );
}
