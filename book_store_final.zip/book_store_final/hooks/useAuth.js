import Cookies from "js-cookie";
import { useRouter } from "next/navigation";
import { useDispatch } from "react-redux";
import { clearToken } from "@/redux/slice/auth-slice";

const useAuth = () => {
  const router = useRouter();
  const dispatch = useDispatch();

  const logout = () => {
    Cookies.remove("auth_token");
    dispatch(clearToken());
    router.push("/login");
    window.location.reload()
  };

  return { logout };
};

export default useAuth;
