import React from "react";

const SkeletonCard = () => {
  return (
    <div className="relative my-10 w-full max-w-xs overflow-hidden rounded-lg bg-gray-200 shadow-md animate-pulse">
      <div className="h-80 bg-gray-300"></div>
      <div className="mt-4 px-5 pb-5">
        <div className="h-6 bg-gray-300 mb-2"></div>
        <div className="h-6 bg-gray-300 w-1/2"></div>
      </div>
    </div>
  );
};

export default SkeletonCard;
