import Link from "next/link";
import React, { useEffect } from "react";
import { FaSearch, FaShoppingBag } from "react-icons/fa";
import { useRouter } from "next/navigation";
import { setToken, setUser } from "@/redux/slice/auth-slice";
import { getMe } from "@/services/products";
import { useDispatch, useSelector } from "react-redux";
import Cookies from "js-cookie";
import useAuth from "@/hooks/useAuth";

const AuthNavbar = ({ toggleMenu, isOpen }) => {
  const router = useRouter();
  const token = Cookies.get("auth_token");
  const { logout } = useAuth();
  const user = useSelector((state) => state.auth.user);
  const cart = useSelector((state) => state.cart.cart);
  const dispatch = useDispatch();

  useEffect(() => {
    if (token) {
      dispatch(setToken(token));
      const fetchMe = async () => {
        const me = await getMe(token);
        dispatch(setUser(me));
      };
      fetchMe();
    }
  }, [dispatch, token]);

  return (
    <div className="ml-auto flex items-center">
      {!token ? (
        <div className="hidden lg:flex lg:flex-1 lg:items-center lg:justify-end lg:space-x-6">
          <Link
            className="text-sm font-medium text-gray-700 hover:text-gray-800"
            href="/login"
          >
            Sign in
          </Link>
          <span className="h-6 w-px bg-gray-200" aria-hidden="true" />
          <Link
            className="text-sm font-medium text-gray-700 hover:text-gray-800"
            href="/register"
          >
            Create account
          </Link>
        </div>
      ) : null}

      <Link
        href="/search"
        className="hidden lg:ml-8 lg:flex text-gray-700 hover:text-gray-800 items-center"
      >
        <FaSearch className="h-6 w-6" aria-hidden="true" />
        <span className="ml-2">Search</span>
      </Link>

      {token ? (
        <div className="relative ml-6">
          <div
            onClick={toggleMenu}
            className="relative flex rounded-full bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800"
          >
            <span className="absolute -inset-1.5" />
            <img className="h-8 w-8 rounded-full" src={user?.avatar} alt="" />
          </div>
          {isOpen && (
            <div className="absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
              <div className="block font-semibold bg-slate-200 px-4 py-2 text-sm text-gray-700">
                {user?.name}
              </div>
              <Link
                href="/profile"
                className="block px-4 py-2 text-sm text-gray-700"
                onClick={() => toggleMenu()}
              >
                Your Profile
              </Link>
              <div
                onClick={() => {
                  toggleMenu();
                  logout();
                  router.push("/");
                }}
                className="block px-4 py-2 text-sm text-gray-700"
              >
                Sign out
              </div>
            </div>
          )}
        </div>
      ) : null}

      <Link href="/basket" className="group ml-4 lg:ml-6 flex items-center">
        <FaShoppingBag
          className="h-6 w-6 flex-shrink-0 text-gray-400 group-hover:text-gray-500"
          aria-hidden="true"
        />
        <span className="ml-2 text-sm font-medium text-gray-700 group-hover:text-gray-800">
          {cart && cart?.length}
        </span>
        <span className="sr-only">items in cart, view bag</span>
      </Link>
    </div>
  );
};

export default AuthNavbar;
