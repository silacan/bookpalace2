"use client";

import React, { useState } from "react";
import { FaBars, FaTimes, FaShoppingBag } from "react-icons/fa";
import Link from "next/link";
import { useSelector } from "react-redux";
import Cookies from "js-cookie";
import AuthNavbar from "./component/auth-navbar";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const token = Cookies.get("auth_token");
  const cart = useSelector((state) => state.cart.cart);
  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <header className="relative z-50">
      <div className="flex h-10 items-center justify-center bg-indigo-600 px-4 text-sm font-medium text-white sm:px-6 lg:px-8">
        Get free delivery on orders over $100
      </div>

      <nav
        aria-label="Top"
        className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 border-b border-gray-200"
      >
        <div className="flex items-center h-16">
          <button
            type="button"
            className="relative rounded-md bg-white p-2 text-gray-400 lg:hidden"
            onClick={toggleMenu}
          >
            <span className="sr-only">Open menu</span>
            {isOpen ? (
              <FaTimes className="h-6 w-6" aria-hidden="true" />
            ) : (
              <FaBars className="h-6 w-6" aria-hidden="true" />
            )}
          </button>

          <div className="ml-4 flex lg:ml-0">
            <Link href="/">Logo</Link>
          </div>

          <div className="hidden lg:ml-8 lg:block lg:self-stretch">
            <div className="flex space-x-8">
              <Link className="px-4 py-6 text-gray-900" href="/">
                Home
              </Link>
              <Link className="px-4 py-6 text-gray-900" href="/products">
                Products
              </Link>
            </div>
          </div>

          <AuthNavbar isOpen={isOpen} toggleMenu={toggleMenu} />
        </div>
      </nav>

      <div className={`lg:hidden ${isOpen ? "" : "hidden"}`}>
        <div className="fixed inset-0 z-40 flex">
          <div
            className="fixed inset-0 bg-black bg-opacity-25"
            onClick={toggleMenu}
            aria-hidden="true"
          />
          <div className="relative flex w-full max-w-xs flex-col overflow-y-auto bg-white pb-12 shadow-xl  px-4 pt-5">
            <button
              type="button"
              className="relative -m-2 inline-flex items-center justify-end rounded-md p-2 text-gray-400"
              onClick={toggleMenu}
            >
              <span className="sr-only">Close menu</span>
              <FaTimes className="h-6 w-6" aria-hidden="true" />
            </button>

            <div className="mt-2">
              <div className="border-b border-gray-200">
                <Link
                  href="/"
                  className="text-gray-900 block p-2 font-medium px-4 py-6"
                >
                  Home
                </Link>
                <Link
                  href="/products"
                  className="text-gray-900 block p-2 font-medium px-4 py-6"
                >
                  Store
                </Link>
              </div>
              {!token ? (
                <div>
                  <Link
                    href="/login"
                    className="text-gray-900 block p-2 font-medium px-4 py-6"
                  >
                    Sign in
                  </Link>
                  <Link
                    href="/register"
                    className="text-gray-900 block p-2 font-medium px-4 py-6"
                  >
                    Create account
                  </Link>
                </div>
              ) : null}
            </div>

            <Link href="/search" className="px-4 py-6">
              Search
            </Link>

            <div className="px-4 py-6">
              <Link
                href="/basket"
                className="text-gray-900 block p-2 font-medium"
              >
                <FaShoppingBag
                  className="h-6 w-6 flex-shrink-0 text-gray-400 group-hover:text-gray-500"
                  aria-hidden="true"
                />
                <span className="ml-2 text-sm font-medium text-gray-700 group-hover:text-gray-800">
                  {cart && cart?.length}
                </span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
