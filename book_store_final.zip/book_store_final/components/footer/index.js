import Link from "next/link";
import React from "react";
import {
  FaFacebookF,
  FaDiscord,
  FaTwitter,
  FaGithub,
  FaDribbble,
} from "react-icons/fa";

const Footer = () => {
  return (
    <footer>
      <div className="mx-auto w-full max-w-screen-xl p-4 py-6 lg:py-8">
        <hr className="my-6 border-gray-200 sm:mx-auto lg:my-8" />
        <div className="sm:flex sm:items-center sm:justify-between">
          <div className="text-sm text-gray-500 sm:text-center">
            © 2024 <span className="hover:underline">Book</span>. All Rights
            Reserved.
          </div>
          <div className="flex mt-4 sm:justify-center sm:mt-0">
            <div className="text-gray-500 hover:text-gray-900">
              <FaFacebookF className="w-4 h-4" />
              <span className="sr-only">Facebook page</span>
            </div>
            <div className="text-gray-500 hover:text-gray-900 ms-5">
              <FaDiscord className="w-4 h-4" />
              <span className="sr-only">Discord community</span>
            </div>
            <div className="text-gray-500 hover:text-gray-900 ms-5">
              <FaTwitter className="w-4 h-4" />
              <span className="sr-only">Twitter page</span>
            </div>
            <div className="text-gray-500 hover:text-gray-900 ms-5">
              <FaGithub className="w-4 h-4" />
              <span className="sr-only">GitHub account</span>
            </div>
            <div className="text-gray-500 hover:text-gray-900 ms-5">
              <FaDribbble className="w-4 h-4" />
              <span className="sr-only">Dribbble account</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

